extends VBoxContainer
class_name CareItem
## One care item on the shelf: icon, name, gauge, hotkey.
## Being a Container, it reports its children's minimum size to the shelf,
## so the row sizes itself instead of collapsing to zero width.

signal picked_up(item: Control)

var icon: Texture2D
var label_text := ""
var hotkey := "1"
var gauge: Gauge

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	focus_mode = Control.FOCUS_NONE
	alignment = BoxContainer.ALIGNMENT_CENTER
	add_theme_constant_override("separation", 2)

	var tr := TextureRect.new()
	tr.texture = icon
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.custom_minimum_size = Vector2(62, 62)
	tr.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(tr)

	var name_lbl := Label.new()
	name_lbl.text = label_text
	name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_lbl.add_theme_font_size_override("font_size", 15)
	name_lbl.add_theme_color_override("font_color", Color("#f6e7d0"))
	name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(name_lbl)

	gauge = Gauge.new()
	add_child(gauge)
	gauge.custom_minimum_size = Vector2(140, 18)
	gauge.radius = 5

	var hk := Label.new()
	hk.text = "KEY " + hotkey
	hk.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hk.add_theme_font_size_override("font_size", 11)
	hk.add_theme_color_override("font_color", Color("#7ff0c0"))
	hk.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hk.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hk)

	mouse_entered.connect(_on_hover.bind(true))
	mouse_exited.connect(_on_hover.bind(false))

func set_lifted(v: bool) -> void:
	modulate = Color(1, 1, 1, 0.32) if v else Color(1, 1, 1, 1)

func _on_hover(entered: bool) -> void:
	if modulate.a >= 0.9:
		modulate = Color(1, 1, 1, 1.14) if entered else Color(1, 1, 1, 1)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT and mb.pressed:
			picked_up.emit(self)
			accept_event()
	elif event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			picked_up.emit(self)
			accept_event()
