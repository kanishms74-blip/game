extends Node2D
## KINDLE — keep Pip, the little ember-spirit, balanced until dawn.
##
## Signature mechanic: CARE IS BALANCE, NOT EXCESS.  Every need has a mint
## comfort band (35..70).  Too little care hurts Pip, but so does smothering
## it.  Drag a care item onto Pip (or press 1/2/3), shoo the Grimlings that
## creep in from the dark, and hold all three gauges inside the band for
## 100 seconds: DUSK -> MIDNIGHT -> STORM -> DAWN.

enum State { TITLE, PLAYING, PAUSED, WON, LOST }

const BANGERS: Font = preload("fonts/Bangers.ttf")

const T_BG: Texture2D = preload("assets/bg_den.jpg")
const T_PIP_OK: Texture2D = preload("assets/pip_content.png")
const T_PIP_HUNGRY: Texture2D = preload("assets/pip_hungry.png")
const T_PIP_COLD: Texture2D = preload("assets/pip_cold.png")
const T_PIP_SAD: Texture2D = preload("assets/pip_sad.png")
const T_BERRY: Texture2D = preload("assets/item_berry.png")
const T_BLANKET: Texture2D = preload("assets/item_blanket.png")
const T_BALL: Texture2D = preload("assets/item_ball.png")
const T_GRIM: Texture2D = preload("assets/grimling.png")
const T_GLOW: Texture2D = preload("assets/glow_dot.png")

const SND_CLICK: AudioStream = preload("audio/ui_click.wav")
const SND_CARE: AudioStream = preload("audio/care.ogg")
const SND_BELL: AudioStream = preload("audio/bell_heavy.ogg")
const SND_HURT: AudioStream = preload("audio/hurt.wav")

const C_MINT := Color("#7ff0c0")
const C_CORAL := Color("#ff6b6b")
const C_CREAM := Color("#f6e7d0")
const C_EMBER := Color("#ff9b54")
const C_INK := Color("#241a30")

const BAND_LO := 35.0
const BAND_HI := 70.0
const CARE_AMT := 30.0
const RUN_TIME := 100.0
const PHASE_NAMES := ["DUSK", "MIDNIGHT", "STORM"]
const PHASE_DRAINS := [2.6, 2.2, 3.0]
const PHASE_MULT := [1.0, 1.35, 1.7]
const NEED_NAMES := ["FULL", "WARM", "GLAD"]
const CARE_COLORS := [Color("#ff8f6b"), Color("#8fd7ff"), Color("#c8ff9e")]
const CARE_TEXTURES: Array = [T_BERRY, T_BLANKET, T_BALL]

var state: State = State.TITLE

# --- run state -------------------------------------------------------------
var _needs: Array[float] = [55.0, 62.0, 48.0]
var _bond := 100.0
var _score := 0
var _combo := 0
var _best := 0
var _elapsed := 0.0
var _spawn_timer := 28.0
var _chill_timer := 9.0
var _chill := 0.0
var _last_phase := 0
var _care_count := 0

# --- world nodes -----------------------------------------------------------
var _bg: Sprite2D
var _vignette: TextureRect
var _flash: ColorRect
var _flash_a := 0.0
var _flash_col := Color(1, 1, 1)
var _bg_target := Color(1, 1, 1)
var _drafts: Node2D
var _pip: Node2D
var _face: Sprite2D
var _shadow: Sprite2D
var _ring: Sprite2D
var _grims: Node2D
var _fx: GPUParticles2D
var _pm: ParticleProcessMaterial
var _camera: Camera2D
var _ghost: Sprite2D
var _ghost_layer: CanvasLayer

# --- HUD / overlays --------------------------------------------------------
var _hud: CanvasLayer
var _hud_root: Control
var _title_root: Control
var _pause_root: Control
var _over_root: Control
var _bond_gauge: Gauge
var _gauges: Array[Gauge] = []
var _items: Array[CareItem] = []
var _bond_box: HBoxContainer
var _phase_box: VBoxContainer
var _score_box: HBoxContainer
var _score_lbl: Label
var _best_lbl: Label
var _combo_lbl: Label
var _phase_lbl: Label
var _timer_lbl: Label
var _shelf: PanelContainer
var _over_title: Label
var _over_sub: Label
var _over_score: Label
var _over_best: Label

# --- layout / motion -------------------------------------------------------
var _vs := Vector2(1280, 720)
var _home := Vector2(538, 500)
var _bounds := Rect2(200, 450, 600, 70)
var _pip_pos := Vector2(538, 500)
var _pip_placed := false
var _relayout_frames := 4
var _drag_index := -1
var _shake_amt := 0.0
var _t := 0.0
var _grim_list: Array[Dictionary] = []


# =============================================================================
# setup
# =============================================================================
func _ready() -> void:
	randomize()
	_load_best()
	_build_world()
	_build_hud()
	_build_overlays()
	get_viewport().size_changed.connect(_apply_layout)
	_apply_layout()

	if get_tree().root.has_meta("auto_start"):
		get_tree().root.remove_meta("auto_start")
		_set_state(State.PLAYING)
	else:
		_set_state(State.TITLE)


func _build_world() -> void:
	_bg = Sprite2D.new()
	_bg.texture = T_BG
	_bg.centered = true
	add_child(_bg)

	_drafts = preload("drafts.gd").new()
	add_child(_drafts)

	_grims = Node2D.new()
	add_child(_grims)

	_pip = Node2D.new()
	_pip.add_to_group("player")
	add_child(_pip)

	_shadow = Sprite2D.new()
	_shadow.texture = T_GLOW
	_shadow.modulate = Color(0, 0, 0, 0.42)
	_shadow.scale = Vector2(0.34, 0.10)
	_shadow.position = Vector2(0, 76)
	_pip.add_child(_shadow)

	_ring = Sprite2D.new()
	_ring.texture = T_GLOW
	_ring.modulate = Color(0.5, 0.94, 0.75, 0.0)
	_ring.scale = Vector2(0.50, 0.50)
	_pip.add_child(_ring)

	_face = Sprite2D.new()
	_face.texture = T_PIP_OK
	_face.scale = Vector2(0.32, 0.32)
	_pip.add_child(_face)

	_fx = GPUParticles2D.new()
	_fx.one_shot = true
	_fx.emitting = false
	_fx.amount = 30
	_fx.lifetime = 0.75
	_fx.explosiveness = 1.0
	_fx.local_coords = false
	_fx.texture = T_GLOW
	_pm = ParticleProcessMaterial.new()
	_pm.direction = Vector3(0, -1, 0)
	_pm.spread = 65.0
	_pm.initial_velocity_min = 90.0
	_pm.initial_velocity_max = 210.0
	_pm.gravity = Vector3(0, 320, 0)
	_pm.scale_min = 0.05
	_pm.scale_max = 0.17
	_pm.color = Color(1, 1, 1)
	_fx.process_material = _pm
	add_child(_fx)

	_vignette = TextureRect.new()
	var grad := Gradient.new()
	grad.set_color(0, Color(0, 0, 0, 0))
	grad.set_color(1, Color(0.04, 0.03, 0.09, 0.62))
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(0.5, 0.02)
	gt.width = 512
	gt.height = 288
	_vignette.texture = gt
	_vignette.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_vignette.stretch_mode = TextureRect.STRETCH_SCALE
	_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_vignette)

	_flash = ColorRect.new()
	_flash.color = Color(1, 1, 1, 0)
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_flash)

	_camera = Camera2D.new()
	_camera.position_smoothing_enabled = false
	add_child(_camera)

	_ghost_layer = CanvasLayer.new()
	_ghost_layer.layer = 25
	add_child(_ghost_layer)


func _build_hud() -> void:
	_hud = CanvasLayer.new()
	_hud.layer = 20
	add_child(_hud)

	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud.add_child(root)
	_hud_root = root

	# --- bond (top left)
	_bond_box = HBoxContainer.new()
	_bond_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bond_box.add_theme_constant_override("separation", 10)
	root.add_child(_bond_box)

	var bond_lbl := _lbl("BOND", 26, C_CREAM, true)
	bond_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	_bond_box.add_child(bond_lbl)

	_bond_gauge = Gauge.new()
	_bond_box.add_child(_bond_gauge)
	_bond_gauge.show_band = false
	_bond_gauge.band_lo = 35.0
	_bond_gauge.band_hi = 100.0
	_bond_gauge.custom_minimum_size = Vector2(230, 24)

	# --- phase + countdown (top centre)
	_phase_box = VBoxContainer.new()
	_phase_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_phase_box.add_theme_constant_override("separation", 0)
	root.add_child(_phase_box)

	_phase_lbl = _lbl("DUSK", 30, C_MINT, true)
	_phase_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_phase_box.add_child(_phase_lbl)

	_timer_lbl = _lbl("DAWN IN 1:40", 20, C_CREAM, true)
	_timer_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_phase_box.add_child(_timer_lbl)

	# --- score + pause (top right)
	_score_box = HBoxContainer.new()
	_score_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_score_box.add_theme_constant_override("separation", 14)
	root.add_child(_score_box)

	var sv := VBoxContainer.new()
	sv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sv.add_theme_constant_override("separation", 0)
	_score_box.add_child(sv)

	_score_lbl = _lbl("0", 32, C_EMBER, true)
	_score_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_score_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sv.add_child(_score_lbl)

	var bl := VBoxContainer.new()
	bl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bl.add_theme_constant_override("separation", 0)
	sv.add_child(bl)

	_best_lbl = _lbl("BEST 0", 15, C_MINT, true)
	_best_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_best_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bl.add_child(_best_lbl)

	_combo_lbl = _lbl("", 22, Color("#ffe08a"), true)
	_combo_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_combo_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bl.add_child(_combo_lbl)

	var pause_btn := _styled_button("PAUSE", 20)
	pause_btn.custom_minimum_size = Vector2(118, 64)
	pause_btn.pressed.connect(_toggle_pause)
	_score_box.add_child(pause_btn)

	# --- care shelf (bottom centre)
	_shelf = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.10, 0.07, 0.14, 0.96)
	sb.set_corner_radius_all(18)
	sb.set_border_width_all(3)
	sb.border_color = Color(0.45, 0.30, 0.24, 0.9)
	sb.set_content_margin_all(14.0)
	_shelf.add_theme_stylebox_override("panel", sb)
	_shelf.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_shelf)

	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 18)
	_shelf.add_child(row)

	for i in 3:
		var it := CareItem.new()
		it.icon = CARE_TEXTURES[i]
		it.label_text = NEED_NAMES[i]
		it.hotkey = str(i + 1)
		row.add_child(it)
		it.picked_up.connect(_on_item_picked.bind(i))
		_items.append(it)
		_gauges.append(it.gauge)


func _build_overlays() -> void:
	# ---- title
	var tl := _layer(30)
	_title_root = _overlay_body(tl, 0.80)
	var tstack := _overlay_stack(_title_root)

	var title := _lbl("KINDLE", 96, C_EMBER, true)
	title.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.65))
	title.add_theme_constant_override("shadow_offset_x", 0)
	title.add_theme_constant_override("shadow_offset_y", 6)
	tstack.add_child(title)

	var sub := _lbl("Keep Pip balanced until the dawn", 24, C_CREAM, false)
	tstack.add_child(sub)

	var card := _card()
	tstack.add_child(card)
	var lines := VBoxContainer.new()
	lines.mouse_filter = Control.MOUSE_FILTER_IGNORE
	lines.add_theme_constant_override("separation", 8)
	card.add_child(lines)
	lines.add_child(_lbl("DRAG a care item onto Pip  ·  or press 1 2 3", 17, Color(0.88, 0.84, 0.94), false))
	lines.add_child(_lbl("CLICK the grimlings before they reach Pip", 17, Color(0.88, 0.84, 0.94), false))
	lines.add_child(_lbl("Hold every gauge INSIDE the mint band —", 17, Color(0.88, 0.84, 0.94), false))
	lines.add_child(_lbl("neglect AND smothering both drain the bond", 17, C_CORAL, false))

	var start_btn := _styled_button("START THE WATCH", 26)
	start_btn.custom_minimum_size = Vector2(340, 70)
	start_btn.pressed.connect(_start_run)
	tstack.add_child(start_btn)

	tstack.add_child(_lbl("SPACE / TAP TO BEGIN", 16, Color(0.72, 0.68, 0.80), true))
	var best_l := _lbl("BEST SCORE  0", 18, C_MINT, true)
	best_l.name = "BestTitle"
	tstack.add_child(best_l)
	set_meta_title_best(best_l)

	# ---- pause
	var pl := _layer(32)
	_pause_root = _overlay_body(pl, 0.72)
	var pstack := _overlay_stack(_pause_root)
	var pcard := _card()
	pstack.add_child(pcard)
	var pv := VBoxContainer.new()
	pv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pv.add_theme_constant_override("separation", 14)
	pcard.add_child(pv)
	pv.add_child(_lbl("PAUSED", 56, C_MINT, true))
	var resume := _styled_button("RESUME", 24)
	resume.custom_minimum_size = Vector2(280, 64)
	resume.pressed.connect(_toggle_pause)
	pv.add_child(resume)
	var restart := _styled_button("RESTART", 24)
	restart.custom_minimum_size = Vector2(280, 64)
	restart.pressed.connect(_restart_run)
	pv.add_child(restart)
	var quit := _styled_button("QUIT TO TITLE", 20)
	quit.custom_minimum_size = Vector2(280, 60)
	quit.pressed.connect(_quit_to_title)
	pv.add_child(quit)
	pv.add_child(_lbl("ESC TO RESUME", 15, Color(0.72, 0.68, 0.80), true))

	# ---- win / lose
	var ol := _layer(34)
	_over_root = _overlay_body(ol, 0.76)
	var ostack := _overlay_stack(_over_root)
	var ocard := _card()
	ostack.add_child(ocard)
	var ov := VBoxContainer.new()
	ov.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ov.add_theme_constant_override("separation", 12)
	ocard.add_child(ov)
	_over_title = _lbl("DAWN BREAKS", 72, C_EMBER, true)
	ov.add_child(_over_title)
	_over_sub = _lbl("Pip made it through the night", 22, C_CREAM, false)
	ov.add_child(_over_sub)
	_over_score = _lbl("SCORE  0", 34, C_MINT, true)
	ov.add_child(_over_score)
	_over_best = _lbl("BEST  0", 20, Color(0.80, 0.76, 0.88), true)
	ov.add_child(_over_best)
	var again := _styled_button("WATCH AGAIN", 26)
	again.custom_minimum_size = Vector2(300, 68)
	again.pressed.connect(_restart_run)
	ov.add_child(again)
	var back := _styled_button("BACK TO TITLE", 18)
	back.custom_minimum_size = Vector2(300, 58)
	back.pressed.connect(_quit_to_title)
	ov.add_child(back)


# =============================================================================
# state machine
# =============================================================================
func _set_state(s: State) -> void:
	state = s
	_hud_root.visible = (s == State.PLAYING or s == State.PAUSED)
	_title_root.visible = (s == State.TITLE)
	_pause_root.visible = (s == State.PAUSED)
	if s != State.WON and s != State.LOST:
		_over_root.visible = false


func _start_run() -> void:
	if state == State.PLAYING:
		return
	_unlock()
	_sfx(SND_CLICK)
	_needs = [55.0, 62.0, 48.0]
	_bond = 100.0
	_score = 0
	_combo = 0
	_elapsed = 0.0
	_spawn_timer = 28.0
	_chill_timer = 9.0
	_chill = 0.0
	_last_phase = 0
	_care_count = 0
	_bg_target = Color(1, 1, 1)
	_drafts.set("alpha_target", 0.0)
	for g in _grim_list:
		var gn: Node2D = g["node"]
		gn.queue_free()
	_grim_list.clear()
	_face.texture = T_PIP_OK
	_set_state(State.PLAYING)
	_announce("DUSK", C_EMBER)


func _toggle_pause() -> void:
	if state == State.PLAYING:
		_unlock()
		_sfx(SND_CLICK)
		_set_state(State.PAUSED)
	elif state == State.PAUSED:
		_unlock()
		_sfx(SND_CLICK)
		_set_state(State.PLAYING)


func _restart_run() -> void:
	_unlock()
	_sfx(SND_CLICK)
	get_tree().root.set_meta("auto_start", true)
	get_tree().reload_current_scene()


func _quit_to_title() -> void:
	_unlock()
	_sfx(SND_CLICK)
	get_tree().reload_current_scene()


func _end_run(won: bool) -> void:
	if won:
		_score += int(_bond * 10.0)
		_flash_col = Color(1.0, 0.87, 0.55)
		_flash_a = 0.7
		_bg_target = Color(1.18, 1.02, 0.80)
		_sfx(SND_BELL)
		_announce("DAWN", C_EMBER)
		_face.texture = T_PIP_OK
		_burst(_pip.position + Vector2(0, -40), Color("#ffd693"), 40)
		_set_state(State.WON)
		_over_title.text = "DAWN BREAKS"
		_over_title.add_theme_color_override("font_color", C_EMBER)
		_over_sub.text = "Pip made it through the night"
	else:
		_flash_col = Color(0.55, 0.62, 1.0)
		_flash_a = 0.4
		_sfx(SND_HURT)
		_announce("THE COLD TOOK PIP", C_CORAL)
		_face.texture = T_PIP_SAD
		_set_state(State.LOST)
		_over_title.text = "PIP DRIFTED OFF"
		_over_title.add_theme_color_override("font_color", Color("#9fb6ff"))
		_over_sub.text = "The den went too cold before dawn"
	if _score > _best:
		_best = _score
		_save_best()
	_over_score.text = "SCORE  %d" % _score
	_over_best.text = "BEST  %d" % _best
	_over_root.visible = false
	var tm := get_tree().create_timer(1.1)
	tm.timeout.connect(_show_over)


func _show_over() -> void:
	if state == State.WON or state == State.LOST:
		_over_root.visible = true


# =============================================================================
# input
# =============================================================================
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed:
			_unlock()
			_handle_click(mb.position, mb.button_index)
	elif event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			_unlock()
			_handle_click(st.position, MOUSE_BUTTON_LEFT)
	elif event is InputEventKey:
		var kb := event as InputEventKey
		if kb.pressed and not kb.echo:
			_unlock()
			_handle_key(kb.keycode)


func _handle_click(pos: Vector2, button: int) -> void:
	match state:
		State.TITLE:
			_start_run()
		State.PLAYING:
			if button == MOUSE_BUTTON_LEFT:
				_try_shoo(pos)
		State.PAUSED:
			pass
		State.WON, State.LOST:
			_restart_run()


func _handle_key(key: int) -> void:
	match state:
		State.TITLE:
			_start_run()
		State.PLAYING:
			match key:
				KEY_1:
					_apply_care(0)
				KEY_2:
					_apply_care(1)
				KEY_3:
					_apply_care(2)
				KEY_ESCAPE:
					_toggle_pause()
		State.PAUSED:
			if key == KEY_ESCAPE or key == KEY_SPACE or key == KEY_ENTER:
				_toggle_pause()
		State.WON, State.LOST:
			if key == KEY_SPACE or key == KEY_ENTER:
				_restart_run()


func _on_item_picked(item: Control, index: int) -> void:
	if state != State.PLAYING or _drag_index >= 0:
		return
	var idx := _items.find(item as CareItem)
	if idx < 0:
		idx = index
	_drag_index = idx
	_ghost = Sprite2D.new()
	_ghost.texture = CARE_TEXTURES[idx]
	_ghost.scale = Vector2(0.20, 0.20)
	_ghost_layer.add_child(_ghost)
	_ghost.position = get_viewport().get_mouse_position()
	_items[idx].set_lifted(true)
	_ring.modulate.a = 0.18
	_sfx(SND_CLICK)


func _update_drag() -> void:
	if _drag_index < 0:
		return
	if state != State.PLAYING:
		_end_drag(false)
		return
	var mp := get_viewport().get_mouse_position()
	if _ghost != null:
		_ghost.position = mp
		_ghost.rotation = sin(_t * 6.0) * 0.09
	var near := mp.distance_to(_pip.position) < 135.0
	_ring.modulate.a = lerpf(_ring.modulate.a, 0.8 if near else 0.18, 0.25)
	if not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_end_drag(near)


func _end_drag(applied: bool) -> void:
	var idx := _drag_index
	_drag_index = -1
	if _ghost != null:
		_ghost.queue_free()
		_ghost = null
	if idx >= 0 and idx < _items.size():
		_items[idx].set_lifted(false)
	_ring.modulate.a = 0.0
	if applied and idx >= 0:
		_apply_care(idx)


# =============================================================================
# gameplay
# =============================================================================
func _physics_process(delta: float) -> void:
	if state != State.PLAYING:
		return
	_elapsed += delta

	# --- grimlings creep in
	_spawn_timer -= delta
	if _spawn_timer <= 0.0:
		_spawn_grim()
		var idx := _phase_index()
		_spawn_timer = [9.5, 7.0, 4.8][idx]

	# --- needs drift out of band
	var mult: float = PHASE_MULT[_phase_index()]
	var chill_now := _chill > 0.0
	for i in 3:
		var d: float = PHASE_DRAINS[i] * mult
		if chill_now and i == 1:
			d += 10.0
		_needs[i] = clampf(_needs[i] - d * delta + randf_range(-3.0, 3.0) * delta, 0.0, 100.0)

	# --- bond: neglect AND smothering both hurt
	var harm := 0.0
	for i in 3:
		var v: float = _needs[i]
		if v < BAND_LO:
			harm += BAND_LO - v
		elif v > BAND_HI:
			harm += (v - BAND_HI) * 1.25
	if harm > 0.0:
		_bond -= harm * 0.20 * delta
	else:
		_bond = minf(_bond + 2.0 * delta, 100.0)

	# --- grimling movement
	for i in range(_grim_list.size() - 1, -1, -1):
		var g: Dictionary = _grim_list[i]
		var gn: Node2D = g["node"]
		var to := _pip.position - gn.position
		var dist := to.length()
		var spd: float = g["speed"]
		if dist < 230.0:
			spd *= 1.65
		if dist > 1.0:
			gn.position += to.normalized() * spd * delta
		var ph: float = g["phase"]
		gn.position += Vector2(sin(_t * 4.0 + ph), cos(_t * 3.3 + ph)) * 11.0 * delta
		gn.rotation = sin(_t * 3.0 + ph) * 0.13
		var s := 1.0 + 0.07 * sin(_t * 6.0 + ph)
		gn.scale = Vector2(s, s)
		if dist < 58.0:
			_grim_hit(i)

	# --- phase transitions
	var idx2 := _phase_index()
	if idx2 != _last_phase:
		_last_phase = idx2
		_sfx(SND_BELL)
		_shake(6.0)
		_flash_col = Color(0.75, 0.85, 1.0)
		_flash_a = 0.32
		_announce(PHASE_NAMES[idx2], C_MINT if idx2 == 1 else Color("#9fc4ff"))
		if idx2 == 2:
			_bg_target = Color(0.62, 0.68, 0.95)

	# --- storm chill waves
	if idx2 == 2:
		_chill_timer -= delta
		if _chill_timer <= 0.0:
			_chill_timer = randf_range(7.0, 10.0)
			_chill = 2.2
			_announce("CHILL DRAFT", Color("#9fd4ff"))
			_flash_col = Color(0.6, 0.75, 1.0)
			_flash_a = 0.28
	if _chill > 0.0:
		_chill -= delta
	_drafts.set("alpha_target", 0.55 if _chill > 0.0 else (0.18 if idx2 == 2 else 0.0))

	# --- player waddle
	var dx := 0.0
	var dy := 0.0
	if InputMap.has_action("move_left") and InputMap.has_action("move_right"):
		dx = Input.get_axis("move_left", "move_right")
		dy = Input.get_axis("move_up", "move_down")
	else:
		dx = (1.0 if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT) else 0.0) \
			- (1.0 if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT) else 0.0)
		dy = (1.0 if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN) else 0.0) \
			- (1.0 if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP) else 0.0)
	var mv := Vector2(dx, dy)
	if mv.length() > 1.0:
		mv = mv.normalized()
	_pip_pos += mv * 165.0 * delta
	_pip_pos.x = clampf(_pip_pos.x, _bounds.position.x, _bounds.position.x + _bounds.size.x)
	_pip_pos.y = clampf(_pip_pos.y, _bounds.position.y, _bounds.position.y + _bounds.size.y)
	if absf(mv.x) > 0.05:
		_face.flip_h = mv.x < 0.0

	# --- endings
	if _bond <= 0.0:
		_bond = 0.0
		_end_run(false)
	elif _elapsed >= RUN_TIME:
		_end_run(true)


func _phase_index() -> int:
	if _elapsed < 35.0:
		return 0
	if _elapsed < 70.0:
		return 1
	return 2


# =============================================================================
# care, shooing, feedback
# =============================================================================
func _apply_care(i: int) -> void:
	if state != State.PLAYING:
		return
	var v: float = _needs[i]
	var nv := clampf(v + CARE_AMT, 0.0, 100.0)
	_needs[i] = nv
	_care_count += 1
	var was_low := v < BAND_LO

	if nv > BAND_HI:
		# smothering: too much care is as harmful as neglect
		_combo = 0
		_bond = maxf(_bond - 8.0, 0.0)
		_sfx(SND_HURT)
		_shake(8.0)
		_flash_col = Color(1.0, 0.55, 0.55)
		_flash_a = 0.22
		_burst(_pip.position + Vector2(0, -30), C_CORAL, 22)
		_float_text("SMOTHERED!", _pip.position + Vector2(0, -96), C_CORAL, 30)
		_pop(_face)
	else:
		_combo += 1
		_score += 100 + 20 * mini(_combo, 10)
		_sfx(SND_CARE)
		_burst(_pip.position + Vector2(0, -30), CARE_COLORS[i], 26)
		if was_low and nv >= BAND_LO:
			_float_text("JUST RIGHT", _pip.position + Vector2(0, -96), C_MINT, 28)
		else:
			_float_text("+ " + NEED_NAMES[i], _pip.position + Vector2(0, -96), CARE_COLORS[i], 26)
		_pop(_face)
		_pop(_items[i])


func _try_shoo(pos: Vector2) -> void:
	for i in range(_grim_list.size() - 1, -1, -1):
		var gn: Node2D = _grim_list[i]["node"]
		if gn.position.distance_to(pos) < 60.0:
			_burst(gn.position, Color("#a893ff"), 24)
			_sfx(SND_BELL)
			_shake(4.5)
			_score += 50
			_float_text("POOF +50", gn.position + Vector2(0, -46), Color("#d6c9ff"), 24)
			gn.queue_free()
			_grim_list.remove_at(i)
			return


func _grim_hit(index: int) -> void:
	var gn: Node2D = _grim_list[index]["node"]
	_burst(gn.position, Color(0.16, 0.12, 0.26), 26)
	gn.queue_free()
	_grim_list.remove_at(index)
	_bond -= 12.0
	_combo = 0
	for i in 3:
		_needs[i] = maxf(_needs[i] - 7.0, 0.0)
	_shake(12.0)
	_flash_col = Color(0.6, 0.55, 1.0)
	_flash_a = 0.35
	_sfx(SND_HURT)
	_float_text("GRIMLED!", _pip.position + Vector2(0, -104), C_CORAL, 32)


func _spawn_grim() -> void:
	if _grim_list.size() >= 4:
		return
	var g := Node2D.new()
	var s := Sprite2D.new()
	s.texture = T_GRIM
	s.scale = Vector2(0.17, 0.17)
	g.add_child(s)
	var edge := randi_range(0, 2)
	var p := Vector2.ZERO
	match edge:
		0:
			p = Vector2(randf_range(50, _vs.x - 50), -60)
		1:
			p = Vector2(-60, randf_range(90, _vs.y * 0.5))
		2:
			p = Vector2(_vs.x + 60, randf_range(90, _vs.y * 0.5))
	g.position = p
	_grims.add_child(g)
	_grim_list.append({
		"node": g,
		"speed": randf_range(54.0, 68.0) + 8.0 * _phase_index(),
		"phase": randf_range(0.0, TAU),
	})


# =============================================================================
# fx helpers
# =============================================================================
func _burst(pos: Vector2, col: Color, count: int) -> void:
	_pm.color = col
	_fx.amount = count
	_fx.position = pos
	_fx.emitting = false
	_fx.emitting = true


func _float_text(text: String, pos: Vector2, col: Color, fsize: int) -> void:
	var lb := _lbl(text, fsize, col, true)
	lb.add_theme_color_override("font_outline_color", Color(0.05, 0.03, 0.08, 0.95))
	lb.add_theme_constant_override("outline_size", 5)
	_hud_root.add_child(lb)
	lb.reset_size()
	var ms := lb.get_combined_minimum_size()
	lb.size = ms
	lb.position = pos - ms * 0.5
	var tw := create_tween()
	tw.tween_property(lb, "position", lb.position + Vector2(0, -58), 1.0)
	tw.parallel().tween_property(lb, "modulate:a", 0.0, 0.6).set_delay(0.4)
	tw.tween_callback(lb.queue_free)


func _announce(text: String, col: Color) -> void:
	var lb := _lbl(text, 58, col, true)
	lb.add_theme_color_override("font_outline_color", Color(0.05, 0.03, 0.08, 0.95))
	lb.add_theme_constant_override("outline_size", 6)
	_hud_root.add_child(lb)
	lb.reset_size()
	var ms := lb.get_combined_minimum_size()
	lb.size = ms
	lb.position = Vector2((_vs.x - ms.x) * 0.5, _vs.y * 0.26)
	lb.scale = Vector2(0.7, 0.7)
	var tw := create_tween()
	tw.tween_property(lb, "scale", Vector2(1.06, 1.06), 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(lb, "modulate:a", 1.0, 0.22)
	tw.tween_interval(0.75)
	tw.tween_property(lb, "modulate:a", 0.0, 0.45)
	tw.tween_callback(lb.queue_free)


func _pop(n: Node) -> void:
	var j: Node = get_node_or_null("/root/Juice")
	if j != null and j.has_method("pop"):
		j.call("pop", n)
		return
	var base: Vector2
	if n is Node2D:
		base = (n as Node2D).scale
	elif n is Control:
		base = (n as Control).scale
	else:
		return
	var tw := create_tween()
	tw.tween_property(n, "scale", base * 1.16, 0.07)
	tw.tween_property(n, "scale", base, 0.15)


func _shake(amount: float) -> void:
	_shake_amt = maxf(_shake_amt, amount)


func _sfx(stream: AudioStream) -> void:
	var a: Node = get_node_or_null("/root/GameAudio")
	if a != null and a.has_method("play"):
		a.call("play", stream)


func _unlock() -> void:
	var a: Node = get_node_or_null("/root/GameAudio")
	if a != null and a.has_method("unlock"):
		a.call("unlock")


# =============================================================================
# per-frame
# =============================================================================
func _process(delta: float) -> void:
	_t += delta
	if _relayout_frames > 0:
		_relayout_frames -= 1
		_apply_layout()

	# camera shake
	if _shake_amt > 0.0:
		_shake_amt = maxf(_shake_amt - delta * 26.0, 0.0)
		if _shake_amt > 0.4:
			_camera.offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * _shake_amt
		else:
			_camera.offset = Vector2.ZERO
	elif _camera.offset != Vector2.ZERO:
		_camera.offset = Vector2.ZERO

	# flash + night grade
	if _flash_a > 0.0:
		_flash_a = maxf(_flash_a - delta * 2.4, 0.0)
	_flash.color = Color(_flash_col.r, _flash_col.g, _flash_col.b, _flash_a)
	_bg.modulate = _bg.modulate.lerp(_bg_target, minf(delta * 1.4, 1.0))

	# pip bob
	var bob := sin(_t * 3.0) * 4.0
	_pip.position = _pip_pos + Vector2(0, bob)
	if state == State.WON:
		_face.scale = Vector2(0.32, 0.32) * (1.0 + 0.06 * sin(_t * 7.0))
	elif state == State.LOST:
		_face.scale = Vector2(0.32, 0.29)
	else:
		_face.scale = Vector2(0.32, 0.32)

	_update_drag()
	_update_face()
	_update_hud()


func _update_face() -> void:
	if state == State.LOST:
		if _face.texture != T_PIP_SAD:
			_face.texture = T_PIP_SAD
		return
	if state == State.WON:
		if _face.texture != T_PIP_OK:
			_face.texture = T_PIP_OK
		return
	var worst := -1
	var worst_gap := 0.0
	for i in 3:
		var gap := 0.0
		var v: float = _needs[i]
		if v < BAND_LO:
			gap = BAND_LO - v
		elif v > BAND_HI:
			gap = (v - BAND_HI) * 0.7
		if gap > worst_gap:
			worst_gap = gap
			worst = i
	if _bond < 30.0:
		worst_gap = maxf(worst_gap, 30.0)
		worst = 2
	var tex: Texture2D = T_PIP_OK
	if worst_gap > 6.0:
		match worst:
			0:
				tex = T_PIP_HUNGRY
			1:
				tex = T_PIP_COLD
			2:
				tex = T_PIP_SAD
	if _face.texture != tex:
		_face.texture = tex
		if tex != T_PIP_OK:
			_pop(_face)


func _update_hud() -> void:
	for i in 3:
		_gauges[i].value = _needs[i]
	_bond_gauge.value = _bond
	_score_lbl.text = "SCORE %d" % _score
	_best_lbl.text = "BEST %d" % _best
	if _combo >= 2:
		_combo_lbl.text = "STREAK x%d" % _combo
	else:
		_combo_lbl.text = ""
	var pidx := _phase_index()
	_phase_lbl.text = PHASE_NAMES[pidx] if state != State.WON else "DAWN"
	if state == State.PLAYING:
		var left: float = maxf(RUN_TIME - _elapsed, 0.0)
		_timer_lbl.text = "DAWN IN %d:%02d" % [int(left) / 60, int(left) % 60]
		if _chill > 0.0:
			_timer_lbl.text = "CHILL %.1f" % _chill
	elif state == State.PAUSED:
		_timer_lbl.text = "PAUSED"
	elif state == State.WON:
		_timer_lbl.text = "SUNRISE"
	else:
		_timer_lbl.text = "NIGHTFALL"


# =============================================================================
# layout
# =============================================================================
func _apply_layout() -> void:
	var vs: Vector2 = get_viewport().get_visible_rect().size
	_vs = vs

	if _bg.texture != null:
		var tw2: float = _bg.texture.get_width()
		var th2: float = _bg.texture.get_height()
		var sc := maxf(vs.x / tw2, vs.y / th2)
		_bg.scale = Vector2(sc, sc)
		_bg.position = vs * 0.5
	_vignette.size = vs
	_flash.size = vs
	_camera.position = vs * 0.5

	# responsive gauge widths on the shelf
	var gw := clampf(vs.x * 0.20, 68.0, 158.0)
	for it in _items:
		it.gauge.custom_minimum_size = Vector2(gw, 18.0)

	# shelf centred along the bottom
	var ms: Vector2 = _shelf.get_combined_minimum_size()
	var k := 1.0
	if ms.x > vs.x - 24.0:
		k = (vs.x - 24.0) / ms.x
	_shelf.scale = Vector2(k, k)
	_shelf.size = ms
	_shelf.position = Vector2((vs.x - ms.x * k) * 0.5, vs.y - ms.y * k - 6.0)
	var shelf_top: float = vs.y - ms.y * k - 6.0

	# top bar
	var bms: Vector2 = _bond_box.get_combined_minimum_size()
	_bond_box.size = bms
	_bond_box.position = Vector2(26, 12)
	var sms: Vector2 = _score_box.get_combined_minimum_size()
	_score_box.size = sms
	_score_box.position = Vector2(vs.x - sms.x - 18, 12)
	var pms: Vector2 = _phase_box.get_combined_minimum_size()
	_phase_box.size = pms
	var left_edge := 18.0 + bms.x
	var right_edge := vs.x - sms.x - 18.0
	var avail := right_edge - left_edge - 28.0
	var pscale := 1.0
	if pms.x > avail and avail > 60.0:
		pscale = avail / pms.x
	_phase_box.scale = Vector2(pscale, pscale)
	_phase_box.position = Vector2((vs.x - pms.x * pscale) * 0.5, 10.0)

	# pip home, above the shelf, on the nest
	var x0 := maxf(90.0, vs.x * 0.42 - 300.0)
	var x1 := minf(vs.x - 90.0, vs.x * 0.42 + 300.0)
	var home := Vector2(clampf(vs.x * 0.42, 110.0, vs.x - 110.0), shelf_top - 82.0)
	var y1 := maxf(home.y - 20.0, shelf_top - 66.0)
	_bounds = Rect2(Vector2(x0, home.y - 55.0), Vector2(maxf(x1 - x0, 80.0), maxf(y1 - (home.y - 55.0), 40.0)))
	_home = home
	if not _pip_placed:
		_pip_placed = true
		_pip_pos = _home
	else:
		_pip_pos.x = clampf(_pip_pos.x, _bounds.position.x, _bounds.position.x + _bounds.size.x)
		_pip_pos.y = clampf(_pip_pos.y, _bounds.position.y, _bounds.position.y + _bounds.size.y)


# =============================================================================
# UI factory
# =============================================================================
func _lbl(text: String, fsize: int, col: Color, use_bangers: bool) -> Label:
	var l := Label.new()
	l.text = text
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if use_bangers:
		l.add_theme_font_override("font", BANGERS)
	l.add_theme_font_size_override("font_size", fsize)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


func _layer(index: int) -> Control:
	var cl := CanvasLayer.new()
	cl.layer = index
	add_child(cl)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cl.add_child(root)
	return root


func _overlay_body(root: Control, dim_alpha: float) -> Control:
	var dim := ColorRect.new()
	dim.color = Color(0.045, 0.035, 0.09, dim_alpha)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dim)
	return root


func _overlay_stack(root: Control) -> VBoxContainer:
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	var stack := VBoxContainer.new()
	stack.alignment = BoxContainer.ALIGNMENT_CENTER
	stack.add_theme_constant_override("separation", 16)
	stack.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stack.alignment = BoxContainer.ALIGNMENT_CENTER
	center.add_child(stack)
	return stack


func _card() -> PanelContainer:
	var p := PanelContainer.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.05, 0.12, 0.93)
	sb.set_corner_radius_all(20)
	sb.set_border_width_all(2)
	sb.border_color = Color(C_MINT.r, C_MINT.g, C_MINT.b, 0.35)
	sb.set_content_margin_all(28.0)
	p.add_theme_stylebox_override("panel", sb)
	return p


func _styled_button(text: String, font_size: int) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(240, 62)
	var n := StyleBoxFlat.new()
	n.bg_color = C_EMBER
	n.set_corner_radius_all(14)
	n.set_border_width_all(3)
	n.border_color = C_INK
	n.set_content_margin_all(14.0)
	var h: StyleBoxFlat = n.duplicate() as StyleBoxFlat
	h.bg_color = Color("#ffb877")
	var p: StyleBoxFlat = n.duplicate() as StyleBoxFlat
	p.bg_color = Color("#d9773c")
	var f: StyleBoxFlat = n.duplicate() as StyleBoxFlat
	f.bg_color = C_EMBER
	f.border_color = C_MINT
	var d: StyleBoxFlat = n.duplicate() as StyleBoxFlat
	d.bg_color = Color(0.45, 0.40, 0.50)
	d.border_color = Color(0.3, 0.26, 0.35)
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", h)
	b.add_theme_stylebox_override("pressed", p)
	b.add_theme_stylebox_override("focus", f)
	b.add_theme_stylebox_override("disabled", d)
	b.add_theme_color_override("font_color", C_INK)
	b.add_theme_color_override("font_hover_color", C_INK)
	b.add_theme_color_override("font_pressed_color", Color(0.12, 0.08, 0.16))
	b.add_theme_color_override("font_focus_color", C_INK)
	b.add_theme_color_override("font_disabled_color", Color(0.7, 0.68, 0.74))
	b.add_theme_font_override("font", BANGERS)
	b.add_theme_font_size_override("font_size", font_size)
	return b


func set_meta_title_best(l: Label) -> void:
	l.text = "BEST SCORE  %d" % _best


# =============================================================================
# persistence
# =============================================================================
func _load_best() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://kindle.cfg") == OK:
		_best = int(cf.get_value("run", "best", 0))


func _save_best() -> void:
	var cf := ConfigFile.new()
	cf.set_value("run", "best", _best)
	cf.save("user://kindle.cfg")
