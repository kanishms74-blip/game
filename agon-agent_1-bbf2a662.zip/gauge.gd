extends Control
class_name Gauge
## A care gauge: 0..100 value with a mint comfort band the player must hold.
## Fill turns coral (and the border pulses) whenever the value leaves the band.

var value := 50.0
var band_lo := 35.0
var band_hi := 70.0
var show_band := true
var good_color := Color("#7ff0c0")
var bad_color := Color("#ff6b6b")
var radius := 6

var _pulse := 0.0
var _bg := StyleBoxFlat.new()
var _fill := StyleBoxFlat.new()
var _band := StyleBoxFlat.new()

func _ready() -> void:
	custom_minimum_size = Vector2(150, 20)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bg.bg_color = Color(0.07, 0.05, 0.11, 0.92)
	_bg.set_corner_radius_all(radius)
	_bg.set_border_width_all(2)
	_bg.border_color = Color(1, 1, 1, 0.16)
	_fill.set_corner_radius_all(radius - 1)
	_band.bg_color = Color(0, 0, 0, 0)
	_band.set_corner_radius_all(radius - 1)
	_band.set_border_width_all(2)
	_band.border_color = good_color
	queue_redraw()

func in_band() -> bool:
	return value >= band_lo and value <= band_hi

func _process(delta: float) -> void:
	_pulse += delta
	queue_redraw()

func _draw() -> void:
	var w := size.x
	var h := size.y
	if w < 6.0 or h < 6.0:
		return
	if not in_band():
		_bg.border_color = Color(1.0, 0.42, 0.42, 0.55 + 0.45 * sin(_pulse * 7.0))
	else:
		_bg.border_color = Color(1, 1, 1, 0.16)
	draw_style_box(_bg, Rect2(0, 0, w, h))
	var fw := clampf(w * clampf(value, 0.0, 100.0) / 100.0, 0.0, w)
	if fw > 5.0:
		_fill.bg_color = good_color if in_band() else bad_color
		draw_style_box(_fill, Rect2(1, 1, fw - 2, h - 2))
	if show_band:
		var bx := w * band_lo / 100.0
		var bw := clampf(w * (band_hi - band_lo) / 100.0, 8.0, w)
		var x1 := minf(bx + bw, w - 2)
		_band.border_color = good_color
		if x1 - bx > 3.0:
			draw_style_box(_band, Rect2(bx, 2, x1 - bx, h - 4))
