extends Node2D
## Wispy cold-draft streaks drawn procedurally. Used for the storm / chill
## waves so the player can SEE the cold coming across the den floor.

var streak_count := 30
var color := Color(0.72, 0.86, 1.0, 0.0)
var speed := 320.0
var length := 54.0
var alpha_target := 0.0

var _seeds: Array[Vector2] = []
var _t := 0.0

func _ready() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261116
	for i in streak_count:
		_seeds.append(Vector2(rng.randf(), rng.randf()))

func _process(delta: float) -> void:
	_t += delta
	color.a = lerpf(color.a, alpha_target, minf(delta * 2.5, 1.0))
	if color.a > 0.01:
		queue_redraw()
	else:
		# clear once faded out
		if _t - floorf(_t) < delta:
			queue_redraw()

func _draw() -> void:
	if color.a < 0.01:
		return
	var vs := get_viewport_rect().size
	for s in _seeds:
		var span := vs.y + 120.0
		var y := fmod(s.y * span + _t * speed * (0.55 + s.x * 0.8), span) - 60.0
		var x := s.x * vs.x
		var ang := 0.42
		draw_line(Vector2(x, y), Vector2(x - length * ang * 2.2, y + length), color, 1.7)
