# PLAN — KINDLE: Keep Them Until Dawn

GAME ANALYSIS
-------------
Fantasy + pillars : Gentle vigil — "I am the only one keeping this little
                    spirit alive through the night." Cozy, tender, tense.
Narrative goal    : Keep Pip, the last ember-spirit, alive and balanced until
                    sunrise (survive the 3-night watch: Dusk → Midnight → Storm → Dawn).
Signature mechanic: **Care is balance, not excess.** Three needs (FULL, WARM,
                    GLAD) each have a comfort BAND — too little OR too much
                    care hurts Pip. Dragging a care item to Pip raises that
                    need; smothering Pip is as deadly as neglecting it.
MDA hypothesis    : Mechanic (band-balancing under drift + time pressure) →
                    player behavior (prioritise the need furthest from band,
                    resist spamming one item) → feeling of attentive,
                    responsible tenderness turning into panic at midnight.
30-second arc     : See Pip + three gauges with green bands → drag a berry,
                    watch FULL rise into band and Pip's face change (first
                    reward) → a need drifts out again and a Grimling creeps in
                    (meaningful choice: feed or shoo) → drain rates rise.
Core loop         : Read gauges → apply the right care item to Pip (or shoo a
                    Grimling) → keep all three needs inside their bands →
                    score/combo grows, Bond holds → escalation to dawn.
Dimension         : 2D
Perspective       : Fixed single-screen interior (side-on den, no camera scroll)
PRIMARY genre     : No listed skill matches a caretaking game — built from the
                    nine invariants + mechanical floor (arcade time-pressure).
Secondary traits  : Reaction arcade — click-to-shoo Grimlings (one hazard verb,
                    subordinate to the care loop; nothing else is borrowed).
                    Plus combo/streak scoring (scored repeated action).

STAGE PLAN — name every stage, describe what changes:
  Stage 1: DUSK (0–35s) — warm amber den, moon visible, gentle drift
           (~3%/s), no hazards. Player learns the bands and the drag verb.
  Stage 2: MIDNIGHT (35–70s) — sky goes deep indigo, window cools, drain
           ~5%/s, Grimlings spawn from the dark edges and creep toward Pip.
           Player must split attention between care and shooing.
  Stage 3: STORM (70–100s) — rain + lightning flashes, WARM drains in bursts
           (chill waves), Grimlings come in pairs, drain ~7%/s.
  Stage 4: DAWN (win) — sky floods gold, Pip glows, "DAWN" reveal, score
           tally. Lose = Bond hits 0 (Pip curls up, Game Over, restart).

ENTITY ROSTER:
  Player        — Pip: a round cream-and-ember fluffy spirit, big eyes, tiny
                  stubby feet. Four faces (content / hungry / cold / sad),
                  128px, soft outline, reads at a glance.
  Hazard        — Grimling: small charcoal shadow-puff with two pale glowing
                  eyes and wispy tail; drifts toward Pip; click to poof it.
  Props/care    — Berry (red glowberry), Folded teal blanket, Yarn ball toy.
                  All sit on the wooden shelf at the bottom; drag to Pip.
  Environment   — Generated den background: wooden room, round window with
                  moon, nest/rug at centre, shelf strip along the bottom,
                  lantern glow. Full-bleed 16:9, painted 2D, no perspective
                  hero-render.

PALETTE          : bg deep indigo #171530 → amber lamplight #3a2a3f;
                    playfield den wood #4b3350 / rug #6b4a5b;
                    player Pip cream #ffe9c9 + ember orange #ff9b54;
                    hazard Grimling charcoal #221c33 with pale eye #c9e8ff;
                    accent (care/in-band) mint #7ff0c0;
                    danger/out-of-band coral #ff6b6b; HUD parchment #f6e7d0.
UI THEME         : Title = Bangers display, ember-orange on indigo with a
                    lamp-glow vignette; HUD = parchment labels + mint band
                    bars; ONE accent colour = mint #7ff0c0 (means "in care").
Fail / win       : Fail = Bond (0–100) reaches 0 from out-of-band needs or a
                    Grimling reaching Pip. Win = survive 100s → Dawn reveal.
Wow beat (≤3 min): Dawn — the whole den floods gold, Pip leaps up glowing,
                    night palette flips to sunrise in one authored flash.
Riskiest feature : Drag-to-care with two-sided failure (overcare harms).
                    Prototype FIRST: drag item → release over Pip → gauge
                    response → band check → Bond drain.

UI LAYOUT (anchors only, never hardcoded pixels)
  Top bar   : Bond bar (left) · phase clock (centre-right) · PAUSE (right).
  Bottom    : care shelf — three 96px items each with its own gauge showing
              the mint comfort band; this is the dead margin, off the den.
  Centre    : Pip on the nest; gauges only ever read from the shelf.
  CanvasLayer: HUD hidden on title/game-over; one state enum drives all screens.
